#ifndef _TIME_SCHEME_CPP

#include "TimeScheme.h"
#include <iostream>

using namespace Eigen;
using namespace std;

// Constructeur par défaut (ne pas oublier de mettre votre pointeur à 0 !!)
TimeScheme::TimeScheme(DataFile* data_file, FiniteVolume* adv) :
_df(data_file), _fin_vol(adv), _t(_df->Get_t0()), _sol(adv->Initial_condition())
{
}

EulerScheme::EulerScheme(DataFile* data_file, FiniteVolume* adv) :
TimeScheme(data_file, adv)
{
}

ImplicitEulerScheme::ImplicitEulerScheme(DataFile* data_file, FiniteVolume* adv) :
TimeScheme(data_file, adv)
{
  std::cout << "Build time scheme class." << std::endl;
  std::cout << "-------------------------------------------------" << std::endl;
}

// Destructeur (car on a des fonctions virtuelles)
TimeScheme::~TimeScheme()
{
}

// Euler Explicite
void EulerScheme::Advance()
{
  this->_fin_vol->Build_flux_mat_and_rhs(this->_t);
  this->_sol=this->_sol-(this->_df->Get_dt()*this->_fin_vol->Get_flux_matrix()*this->_sol+this->_fin_vol->Get_BC_RHS())+this->_df->Get_dt()*this->_fin_vol->Source_term(this->_t);
}

// Euler Implicite
void ImplicitEulerScheme::Advance()
{
  this->_fin_vol->Build_flux_mat_and_rhs(this->_t+this->_df->Get_dt());
  SparseMatrix<double> A;
  A.resize(this->_sol.size(),this->_sol.size());
  vector<Triplet<double>> triplets;	triplets.clear();
  for(int i=0;i<this->_sol.size();i++)
  {
    triplets.push_back({i,i,1});
  }
  A.setFromTriplets(triplets.begin(), triplets.end());
  A=A+this->_df->Get_dt()*this->_fin_vol->Get_flux_matrix();
  this->_solver_direct.compute(A);
  VectorXd  y = this->_sol+this->_df->Get_dt()*this->_fin_vol->Source_term(this->_t+this->_df->Get_dt())-this->_df->Get_dt()*this->_fin_vol->Get_BC_RHS();
  this->_sol = this->_solver_direct.solve(y);
}

#define _TIME_SCHEME_CPP
#endif
