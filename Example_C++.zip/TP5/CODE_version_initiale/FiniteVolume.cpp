#ifndef _FINITEVOLUME_CPP
#include "FiniteVolume.h"
#include <fstream>
#include <iostream>
#include <cmath>

using namespace std;
using namespace Eigen;

// Constructeur
FiniteVolume::FiniteVolume(Function* function, DataFile* data_file, Mesh2D* mesh) :
_fct(function), _df(data_file), _msh(mesh)
{
	std::cout << "Build finite volume class." << std::endl;
	std::cout << "-------------------------------------------------" << std::endl;
}

double FiniteVolume::max(double a, double b)
{
	if(a>=b)
	{
		return a;
	}
	else
	{
		return b;
	}
}

// Construit la matrice des flux et les conditions de bord ( vecteur b )
void FiniteVolume::Build_flux_mat_and_rhs(const double& t)
{
	// Matrix
	this->_mat_flux.resize(this->_msh->Get_triangles().size(),this->_msh->Get_triangles().size());
	// RHS
	this->_BC_RHS.resize(this->_msh->Get_triangles().size());
	this->_BC_RHS.setZero();
	vector<Triplet<double>> triplets;	triplets.clear();
	vector<Edge> Tab = this->_msh->Get_edges();
	for (int i = 0; i < this->_msh->Get_edges().size(); i++)
	{
		//ATTENTION : si on est au bord ou pas : on récupère T1 et T2 ou que l'un des deux.
		int t1 = Tab[i].Get_T1();
		int t2 = Tab[i].Get_T2();

		string scen = this->_df->Get_scenario();

		double alphaA=0,betaA=0;
		double Vx=this->_fct->Velocity_x(this->_msh->Get_edges_center()(i,0),this->_msh->Get_edges_center()(i,1),t);
		double Vy=this->_fct->Velocity_y(this->_msh->Get_edges_center()(i,0),this->_msh->Get_edges_center()(i,1),t);
		double V=Vx*this->_msh->Get_edges_normal()(i,0)+Vy*this->_msh->Get_edges_normal()(i,1);
		if(scen=="centered")
		{
			alphaA=V/2;
			betaA=V/2;
		}
		else
		{
			alphaA=max(V,0.);
			betaA=-max(-V,0.);
		}
		if(t1>-1&&t2>-1)
		{
			double x_carre = (this->_msh->Get_triangles_center()(t1,0)-this->_msh->Get_triangles_center()(t2,0))*(this->_msh->Get_triangles_center()(t1,0)-this->_msh->Get_triangles_center()(t2,0));
			double y_carre = (this->_msh->Get_triangles_center()(t1,1)-this->_msh->Get_triangles_center()(t2,1))*(this->_msh->Get_triangles_center()(t1,1)-this->_msh->Get_triangles_center()(t2,1));
			double delta = pow(x_carre+y_carre,1./2);
			double coeff0 = this->_msh->Get_edges_length()(i)*(this->_df->Get_mu()/delta+alphaA)/this->_msh->Get_triangles_area()(t1);
			triplets.push_back({t1,t1,coeff0});
			coeff0 = this->_msh->Get_edges_length()(i)*(-this->_df->Get_mu()/delta+betaA)/this->_msh->Get_triangles_area()(t1);
			triplets.push_back({t1,t2,coeff0});
			coeff0 = this->_msh->Get_edges_length()(i)*(this->_df->Get_mu()/delta+alphaA)/this->_msh->Get_triangles_area()(t2);
			triplets.push_back({t2,t1,-coeff0});
			coeff0 = this->_msh->Get_edges_length()(i)*(-this->_df->Get_mu()/delta+betaA)/this->_msh->Get_triangles_area()(t2);
			triplets.push_back({t2,t2,-coeff0});//alpha et beta en fin de page 6 : comme que advection, on garde que les alpha^A et on a se définition
		}
		else
		{
			//t2 est toujours nul dans ce cas
			//Calcul de delta pour l'advection, qui ici est la distance entre le triangle et le bord
			double x_carre = (this->_msh->Get_triangles_center()(t1,0)-this->_msh->Get_edges_center()(i,0))*(this->_msh->Get_triangles_center()(t1,0)-this->_msh->Get_edges_center()(i,0));
			double y_carre = (this->_msh->Get_triangles_center()(t1,1)-this->_msh->Get_edges_center()(i,1))*(this->_msh->Get_triangles_center()(t1,1)-this->_msh->Get_edges_center()(i,1));
			double delta_i_e = pow(x_carre+y_carre,1./2);
			double coeff = this->_msh->Get_edges_length()(i)/this->_msh->Get_triangles_area()(t1);
			
			if(Tab[i].Get_BC()=="Neumann")
			{
				// !!! On met "+=" car : On met les conditions de bord dans bc_rhs en les rangeant par triangle. Mais pour un triangle dans un coin, on va devoir ajouter les flux des deux aretes ; on ne veut pas supprimer celui de la première arete au moment de mettre celui de la seconde.
				double diff = -coeff*this->_df->Get_mu()*this->_fct->Neumann_Function(this->_msh->Get_edges_center()(i,0),this->_msh->Get_edges_center()(i,1),t);
				double adv = betaA*coeff*this->_fct->Neumann_Function(this->_msh->Get_edges_center()(i,0),this->_msh->Get_edges_center()(i,1),t)*2*delta_i_e;
				this->_BC_RHS(t1)+=diff+adv;
				triplets.push_back({t1,t1,coeff*(alphaA+betaA)}); // Ce que l'advection rajoute à la matrice
			}
			else
			{
				double adv_BC = 2*betaA*coeff*this->_fct->Dirichlet_Function(this->_msh->Get_edges_center()(i,0),this->_msh->Get_edges_center()(i,1),t) ;
				double diff_BC = -coeff*this->_df->Get_mu()/delta_i_e*this->_fct->Dirichlet_Function(this->_msh->Get_edges_center()(i,0),this->_msh->Get_edges_center()(i,1),t);
				this->_BC_RHS(t1)+= diff_BC+adv_BC;
				double adv_mat = coeff*(alphaA-betaA);
				double diff_mat = coeff*this->_df->Get_mu()/delta_i_e ;
				triplets.push_back({t1,t1,diff_mat+adv_mat});
			}
		}
	}
	this->_mat_flux.setFromTriplets(triplets.begin(), triplets.end());
	cout << "matrice A" << endl;
	cout << this->_mat_flux << endl;
	cout << "-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_--_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_--_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-" << endl;
	cout << "b" << endl;
	cout << this->_BC_RHS << endl;
}


// --- Déjà implémenté ---
// Construit la condition initiale au centre des triangles
VectorXd FiniteVolume::Initial_condition()
{
	VectorXd sol0(this->_msh->Get_triangles().size());

	for (int i = 0; i < this->_msh->Get_triangles().size(); i++)
	{
		sol0(i) = this->_fct->Initial_condition(this->_msh->Get_triangles_center()(i,0),
															this->_msh->Get_triangles_center()(i,1));
	}

	return sol0;
}

// Terme source au centre des triangles
VectorXd FiniteVolume::Source_term(double t)
{
	VectorXd sourceterm(this->_msh->Get_triangles().size());

	for (int i = 0; i < this->_msh->Get_triangles().size(); i++)
	{
		sourceterm(i) = this->_fct->Source_term(this->_msh->Get_triangles_center()(i,0),
							this->_msh->Get_triangles_center()(i,1), t);
	}

	cout << ":.:.:.:.:.:.:.:.:.:.:.:.:.:.:.:.:.:.:.:.:.:.:.:.:.:.:.:.:.:.:.:.:.:.:.:." << endl;
	cout << "S" << endl;
	cout << sourceterm << endl;
	return sourceterm;
}

// Solution exacte au centre des triangles
VectorXd FiniteVolume::Exact_solution(const double t)
{
	VectorXd exactsol(this->_msh->Get_triangles().size());

	for (int i = 0; i < this->_msh->Get_triangles().size(); i++)
	{
		exactsol(i) = this->_fct->Exact_solution(this->_msh->Get_triangles_center()(i,0),
							this->_msh->Get_triangles_center()(i,1), t);
	}
	return exactsol;
}

// Sauvegarde la solution
void FiniteVolume::Save_sol(const Eigen::VectorXd& sol, int n, std::string st)
{
	double norm = 0;
	for (int i = 0; i < sol.rows(); i++)
	norm += sol(i)*sol(i)*this->_msh->Get_triangles_area()[i];
	norm = sqrt(norm);

	if (st == "solution")
	{
		cout << "Norme de u = " << norm << endl;
	}

	string name_file = this->_df->Get_results() + "/" + st + "_" + std::to_string(n) + ".vtk";
	int nb_vert = this->_msh->Get_vertices().size();
	assert((sol.size() == this->_msh->Get_triangles().size())
	&& "The size of the solution vector is not the same than the number of _triangles !");

	ofstream solution;
	solution.open(name_file, ios::out);
	solution.precision(7);

	solution << "# vtk DataFile Version 3.0 " << endl;
	solution << "2D Unstructured Grid" << endl;
	solution << "ASCII" << endl;
	solution << "DATASET UNSTRUCTURED_GRID" << endl;

	solution << "POINTS " << nb_vert << " float " << endl;
	for (int i = 0 ; i < nb_vert ; ++i)
	{
		solution << ((this->_msh->Get_vertices()[i]).Get_coor())[0] << " "
		<< ((this->_msh->Get_vertices()[i]).Get_coor())[1] << " 0." << endl;
	}
	solution << endl;

	solution << "CELLS " << this->_msh->Get_triangles().size() << " "
	<< this->_msh->Get_triangles().size()*4 << endl;
	for (int i = 0 ; i < this->_msh->Get_triangles().size() ; ++i)
	{
		solution << 3 << " " << ((this->_msh->Get_triangles()[i]).Get_vertices())[0]
		<< " " << ((this->_msh->Get_triangles()[i]).Get_vertices())[1]
		<< " " << ((this->_msh->Get_triangles()[i]).Get_vertices())[2] << endl;
	}
	solution << endl;

	solution << "CELL_TYPES " << this->_msh->Get_triangles().size() << endl;
	for (int i = 0 ; i < this->_msh->Get_triangles().size() ; ++i)
	{
		solution << 5 << endl;
	}
	solution << endl;

	solution << "CELL_DATA " << this->_msh->Get_triangles().size() << endl;
	solution << "SCALARS sol float 1" << endl;
	solution << "LOOKUP_TABLE default" << endl;
	// To avoid strange behaviour (which appear only with Apple)
	// with Paraview when we have very small data (e-35 for example)
	double eps = 1.0e-10;
	for (int i = 0 ; i < this->_msh->Get_triangles().size() ; ++i)
	{
		solution << max(eps,sol[i]) << endl;
	}
	solution << endl;

	//solution << "CELL_DATA " << this->_msh->Get_triangles().size() << endl;
	solution << "SCALARS CFL float 1" << endl;
	solution << "LOOKUP_TABLE default" << endl;
	// To avoid strange behaviour (which appear only with Apple)
	// with Paraview when we have very small data (e-35 for example)
	for (int i = 0 ; i < this->_msh->Get_triangles().size() ; ++i)
	{
		solution << max(eps,this->_df->Get_dt()*fabs(sol[i])/this->_msh->Get_triangles_length()(i)) << endl;
	}
	solution << endl;

	if (this->_df->Get_mu() > 1e-10)
	{
		solution << "SCALARS Pe float 1" << endl;
		solution << "LOOKUP_TABLE default" << endl;
		// To avoid strange behaviour (which appear only with Apple)
		// with Paraview when we have very small data (e-35 for example)
		for (int i = 0 ; i < this->_msh->Get_triangles().size() ; ++i)
		{
			solution << max(eps,this->_msh->Get_triangles_length()(i)*fabs(sol[i])/this->_df->Get_mu()) << endl;
		}
		solution << endl;
	}

	solution.close();
}

#define _FINITEVOLUME_CPP
#endif
